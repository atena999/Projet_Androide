import os

DATA_PATH = os.path.abspath(__file__)
DATA_PATH = os.path.dirname(DATA_PATH)
